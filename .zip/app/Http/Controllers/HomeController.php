<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Image;
class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function home()
    {
        if(  Session::get('employee_role') == "admin"){
        $data = DB::table('add_files')
                       // ->where('emple_id', Session::get('empolyee_id') )
                    ->select('*')
                    ->get();

        return view('theme.index',['data'=>$data]);
        }elseif(Session::get('employee_role') == "user"){
            $data = DB::table('add_files')
            // ->where('emple_id', Session::get('empolyee_id') )
         ->select('*')
         ->get();

        return view('theme.view',['data'=>$data]);
        }
    }
    public function addFiles()
    {
        if(  Session::get('employee_role') == "admin"){
        $data = "";
        return view('theme.add_files',['data'=>$data]);
        }else{
            echo "Please login Admin";
        }

    }
    public function addFilesUpload(Request $request)
    {
        if(  Session::get('employee_role') == "admin"){
        $validate = Validator::make($request->all(), [
            'title' => 'required|min:5',
            'Dis' => 'required',
            'photos' => 'required',
        ],[
            'title.required' => 'Title is must.',
            'Dis.min' => 'Title must have 5 char.',
        ]);
        if($validate->fails()){
                return back()->withErrors($validate->errors())->withInput();
        }else{

                    $file = $request->file('photos');
                    $extension =  $file->getClientOriginalExtension(); 
                    $name = time().'.'.$file->extension();
                    $img =\Image::make($file);
                    $img->save(\public_path('/files/'.$name),50);
                   // $file->move(public_path().'/files/', $name);  
                    // $data[] = $name;
                    // $i = $i+1;
                    if($request->input('optional')){
                        $opt =$request->input('optional');
                    }else{
                        $opt = "off";
                    }
                    $datas = DB::table('add_files')->insertGetId(
						[   
							'title'		=> $request->input('title'),
							'dis'		=> $request->input('Dis'),
							'image'		=> $name,
							'private'		=> $opt,
							'status'	=> 1 
						   
				    ]); 
				   	$data = DB::table('add_files')
                       // ->where('emple_id', Session::get('empolyee_id') )
                    ->select('*')
                    ->get();
                    return view('theme.index',['data'=>$data]);
				       
		}
        }else{
            echo "Please login Admin";
        }
    }
    public function EditsUpload(Request $request)
    {
        if(  Session::get('employee_role') == "admin"){
                    if($request->input('optional')){
                        $opt =$request->input('optional');
                    }else{
                        $opt = "off";
                    }
                    $datas = DB::table('add_files')->where('id',$request->input('id'))->update(
						[   
							'title'		=> $request->input('title'),
							'dis'		=> $request->input('Dis'),
							//  'image'		=> $name,
							'private'		=> $opt,
							'status'	=> 1 
						   
				    ]); 
				   	$data = DB::table('add_files')
                       // ->where('emple_id', Session::get('empolyee_id') )
                    ->select('*')
                    ->get();
                    return view('theme.index',['data'=>$data]);
				       
		}else{
            echo "Please Login Admin";
        }
    }
    public function editFiles($id)
    {
        if(  Session::get('employee_role') == "admin"){
            $data = DB::table('add_files')
                        ->where('id', $id )
                        ->select('*')
                        ->get();
            return view('theme.add_files',['data'=>$data]);
        }else{
            echo "Please Login Admin";
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function delete($id)
    {
        if(  Session::get('employee_role') == "admin"){
            $data = DB::table('add_files')
                        ->where('id', $id )
                        ->delete();
            return redirect('/dasboard');
        }else{
            echo "Please Login Admin";
        }
        
    }
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
